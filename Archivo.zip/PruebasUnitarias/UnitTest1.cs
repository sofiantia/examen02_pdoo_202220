﻿using Reforestacion;
using LogicaReforestacion;

namespace PruebasUnitarias;


[TestClass]
public class UnitTest1
{
    [TestMethod]
    public void TestMethod1()
    {
        //Arrange
        Arbol[] arbolPrueba =
        {
          new Arbol() { Proveedor = "Privado", CantidadArboles = 450 },
          
        };

        Corantioquia cooprueba = new Corantioquia (arbolPrueba);


        //Act

        cooprueba.CalculaLitros();

        //Assert

        float GalonesEsperado = 4500;
        float GalonesObtenido = cooprueba.galonesagua;
            

        Assert.AreEqual(GalonesEsperado, GalonesObtenido);
    }

    [TestMethod]
    public void TestMethod2()
    {
        //Arrange
        Arbol[] arbolPrueba =
        {
          new Arbol() { CantidadArboles = 559 },

        };

        Corantioquia cooprueba = new Corantioquia(arbolPrueba);


        //Act

        cooprueba.DeterminaExito();

        //Assert

        bool ExitoEsperado = false;
        bool ExitoObtenido = cooprueba.Exitoso;


        Assert.AreEqual(ExitoEsperado, ExitoObtenido);
    }

    [TestMethod]
    public void TestMethod3()
    {
        //Arrange
        Arbol[] arbolPrueba =
        {
          new Arbol() { CantidadArboles = 700},

        };

        Corantioquia cooprueba = new Corantioquia(arbolPrueba);


        //Act

        cooprueba.CalculaPorcentaje();

        //Assert

        float PorcentajeEsperado = 70;
        float porcentajeObtenido = cooprueba.PorcentajeSobrevivente;


        Assert.AreEqual(PorcentajeEsperado, porcentajeObtenido);
    }
}
